package com.example.acer.bakeit;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.acer.bakeit.model.Ingredient;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.List;

import static com.android.volley.VolleyLog.TAG;

public class WidgetRemoveViews extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        Log.d(TAG, "onGetViewFactory: ");
        return new WidgetModel(this.getApplicationContext(),intent);
    }
    public  class WidgetModel implements RemoteViewsService.RemoteViewsFactory{
        Context ct;
        Intent intent;
        List<Ingredient>ingredientList;

        public WidgetModel(Context ct, Intent intent) {
            this.ct = ct;
            this.intent = intent;
        }

        @Override
        public void onCreate() {

        }

        @Override
        public void onDataSetChanged() {
            SharedPreferences sharedPreferences=getSharedPreferences("data",Context.MODE_PRIVATE);
            String Datatext=sharedPreferences.getString("Widget","");
            ingredientList=new Gson().fromJson(Datatext,new TypeToken<List<Ingredient>>(){
            }.getType());
            Log.d(TAG, "onDataSetChanged: "+ingredientList.size());

        }

        @Override
        public void onDestroy() {

        }

        @Override
        public int getCount() {
            return ingredientList.size();
        }

        @Override
        public RemoteViews getViewAt(int i) {
            RemoteViews remoteViews=new RemoteViews(ct.getPackageName(),R.layout.widraw);
            remoteViews.setTextViewText(R.id. textView,"Ingredient: "+ingredientList.get(i).getIngredient());
            remoteViews.setTextViewText(R.id.textView1,"Quantity: "+ingredientList.get(i).getQuantity());
            remoteViews.setTextViewText(R.id.textView2,ingredientList.get(i).getMeasure());
            return remoteViews;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }
    }
}
