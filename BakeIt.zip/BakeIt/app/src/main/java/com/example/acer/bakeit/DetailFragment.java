package com.example.acer.bakeit;

import android.app.Activity;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.CollapsingToolbarLayout;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.squareup.picasso.Picasso;


public class DetailFragment extends Fragment {

    SimpleExoPlayerView simpleExoPlayerView;
    SimpleExoPlayer exoPlayer;
    long currentpostion;
    PlaybackStateCompat.Builder playback=new PlaybackStateCompat.Builder();
    MediaSessionCompat mcompat;
    TextView textView;
    String desc;
    String videourl;
    String thumbnail;
    ImageView imageView;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if (getArguments().containsKey("videoUrllink")||getArguments().containsKey("stepDescription")) {
            videourl=getArguments().getString("videoUrllink");
            desc=getArguments().getString("stepDescription");
            thumbnail=getArguments().getString("thumbnailURL");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.item_detail, container, false);

        textView=rootView.findViewById(R.id.tv2);
        simpleExoPlayerView=rootView.findViewById(R.id.exo);
        imageView=rootView.findViewById(R.id.exoimage);
        textView.setText(desc);

        if(TextUtils.isEmpty(videourl)){

            if (TextUtils.isEmpty(thumbnail))
            {
                imageView.setVisibility(View.VISIBLE);
                simpleExoPlayerView.setVisibility(View.GONE);
            }
            else {
                videourl=thumbnail;
                Picasso.with(getActivity()).load(thumbnail).into(imageView);
                simpleExoPlayerView.setVisibility(View.VISIBLE);

            }

        }
        intializePlayer();
        if(savedInstanceState!=null){
            currentpostion=savedInstanceState.getLong("currentpos");
            exoPlayer.seekTo(currentpostion);
            boolean currentplay=savedInstanceState.getBoolean("currentpalyback");
            exoPlayer.setPlayWhenReady(currentplay);

        }


        return rootView;
    }

    public void intializePlayer()
    {


        BandwidthMeter bandwidthMeter=new DefaultBandwidthMeter();
        TrackSelector trackSelector=new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(bandwidthMeter));
        LoadControl loadControl=new DefaultLoadControl();
        exoPlayer= ExoPlayerFactory.newSimpleInstance(getContext(),trackSelector,loadControl);
        Uri VideoURI=Uri.parse(String.valueOf(videourl));
        DefaultHttpDataSourceFactory dataSourceFactory=new DefaultHttpDataSourceFactory("exoplayer_video");
        ExtractorsFactory extractorsFactory=new DefaultExtractorsFactory();

        MediaSource mediaSource=new ExtractorMediaSource(VideoURI,dataSourceFactory,extractorsFactory,null,null);
        simpleExoPlayerView.setPlayer(exoPlayer);
        exoPlayer.prepare(mediaSource);
        exoPlayer.setPlayWhenReady(true);


    }



    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
            outState.putLong("currentpos",exoPlayer.getCurrentPosition());
            outState.putBoolean("currentpalyback",exoPlayer.getPlayWhenReady());
    }

    @Override
    public void onPause() {
        super.onPause();
        exoPlayer.release();
        exoPlayer.stop();
    }

    @Override
    public void onStop() {
        super.onStop();
        exoPlayer.release();
        exoPlayer.stop();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(exoPlayer==null) {
            exoPlayer.release();
            exoPlayer.stop();
        }
    }
}
