package com.example.acer.bakeit;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.acer.bakeit.model.Receipe;
import com.example.acer.bakeit.model.Step;
import com.google.gson.Gson;

import java.util.List;


public class Myadapter extends RecyclerView.Adapter<Myadapter.MyViewHolder> {
    List<Receipe> list;
    List<Step>steps;
    Context context;

    public Myadapter(MainActivity mainActivity, List<Receipe> list, List<Step> steps) {
        this.context=mainActivity;
        this.list=list;
        this.steps=steps;
    }

    @NonNull
    @Override
    public Myadapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_view,viewGroup,false);
        return new MyViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull Myadapter.MyViewHolder myViewHolder, int i) {
        myViewHolder.textView1.setText(list.get(i).getName());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textView1;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textView1=itemView.findViewById(R.id.tv1);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int adaPosition=getAdapterPosition();

            Intent intent=new Intent(context,ListActivity.class);
            intent.putExtra("stepdetails",list.get(adaPosition).getSteps());
            intent.putParcelableArrayListExtra("steps",list.get(adaPosition).getSteps());
            intent.putExtra("ingdetails",list.get(adaPosition).getIngredients());
            intent.putParcelableArrayListExtra("ingredients",list.get(adaPosition).getIngredients());
            intent.putExtra("pos",adaPosition);
            itemView.getContext().startActivity(intent);

            SharedPreferences sharedPreferences=context.getSharedPreferences("data",Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putString("Widget",new Gson().toJson(list.get(adaPosition).getIngredients()));
            editor.apply();

            Intent i=new Intent(context,ReceipeIntentServiceclass.class);
            i.setAction("IntentServiceAction");
            context.startService(i);
        }
    }
}
