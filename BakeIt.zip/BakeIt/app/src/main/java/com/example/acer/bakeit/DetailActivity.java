package com.example.acer.bakeit;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.NavUtils;
import android.view.MenuItem;
import com.example.acer.bakeit.model.Step;
import java.util.ArrayList;


public class DetailActivity extends AppCompatActivity {
    ArrayList<Step> mlist;
    int position;
    String videourl, desc,thumbnail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);
        position = getIntent().getIntExtra("pos", 0);
        mlist = new ArrayList<>();

        if (savedInstanceState == null) {
            videourl = getIntent().getStringExtra("videoUrllink");
            desc = getIntent().getStringExtra("stepDescription");
            thumbnail=getIntent().getStringExtra("thumbnailURL");

            Bundle arguments = new Bundle();
            arguments.putString("videoUrllink", videourl);
            arguments.putString("stepDescription", desc);
            arguments.putString("thumbnailURL",thumbnail);
            arguments.putInt("pos",position);
            DetailFragment fragment = new DetailFragment();
            fragment.setArguments(arguments);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.itemlist_detail_container, fragment)
                    .commit();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            NavUtils.navigateUpTo(this, new Intent(this, ListActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
