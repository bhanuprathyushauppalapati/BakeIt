package com.example.acer.bakeit;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.design.widget.FloatingActionButton;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.acer.bakeit.model.Ingredient;
import com.example.acer.bakeit.model.Step;
import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
    ArrayList<Step> arrayList;
    ArrayList<Ingredient> ingredientArrayList;
    FloatingActionButton floatingActionButton;

    private boolean mTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        arrayList=getIntent().getParcelableArrayListExtra("stepdetails");
        ingredientArrayList=getIntent().getParcelableArrayListExtra("ingdetails");

        floatingActionButton =findViewById(R.id.fab);
        floatingActionButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ListActivity.this,DisplayIngredientsActivity.class);
                intent.putExtra("ingredients",ingredientArrayList);
                startActivity(intent);
            }
        });

        if (findViewById(R.id.itemlist_detail_container) != null) {
            mTwoPane = true;
        }
        View recyclerView = findViewById(R.id.item_list);
        assert recyclerView != null;
        setupRecyclerView((RecyclerView) recyclerView);
    }


    private void setupRecyclerView( RecyclerView recyclerView) {
        recyclerView.setAdapter(new SimpleItemRecyclerViewAdapter(this, arrayList, ingredientArrayList, mTwoPane));
    }

    public static class SimpleItemRecyclerViewAdapter
            extends RecyclerView.Adapter<SimpleItemRecyclerViewAdapter.ViewHolder> {

        private final ListActivity mParentActivity;
        private final ArrayList<Step> steplist;
        private final ArrayList<Ingredient> ing1;
        private final boolean mTwopane;
        SimpleItemRecyclerViewAdapter(ListActivity parent,
                                      ArrayList<Step> items,
                                      ArrayList<Ingredient> ingredientArrayList, boolean twoPane) {
            steplist = items;
            mParentActivity = parent;

            ing1 = ingredientArrayList;
            mTwopane = twoPane;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, final int position) {


            holder.mIdView.setText(steplist.get(position).getId().toString());
            holder.mContentView.setText(steplist.get(position).getShortDescription());

        }

        @Override
        public int getItemCount() {
            return steplist.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            final TextView mIdView;
            final TextView mContentView;

            ViewHolder(View view) {
                super(view);
                mIdView =  view.findViewById(R.id.id_text);
                mContentView = view.findViewById(R.id.content);
                itemView.setOnClickListener(this);
            }

            @Override
            public void onClick(View v) {
                int adapterPosition = getAdapterPosition();

                if (mTwopane) {

                    Bundle arguments = new Bundle();
                    arguments.putString("videoUrllink", steplist.get(adapterPosition).getVideoURL());
                    arguments.putString("stepDescription", steplist.get(adapterPosition).getDescription());
                    arguments.putString("thumbnailURL",steplist.get(adapterPosition).getThumbnailURL());
                    DetailFragment fragment = new DetailFragment();
                    fragment.setArguments(arguments);
                    mParentActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.itemlist_detail_container, fragment)
                            .commit();
                }
                else
                    {
                    Intent intent = new Intent(mParentActivity, DetailActivity.class);
                    intent.putExtra("videoUrllink", steplist.get(adapterPosition).getVideoURL());
                    intent.putExtra("stepDescription", steplist.get(adapterPosition).getDescription());
                    intent.putExtra("thumbnailURL",steplist.get(adapterPosition).getThumbnailURL());
                    intent.putParcelableArrayListExtra("desList", steplist);
                    intent.putExtra("pos", getAdapterPosition());
                    mParentActivity.startActivity(intent);
                }

            }

        }
    }
}
