package com.example.acer.bakeit;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;


import com.example.acer.bakeit.model.Ingredient;

import java.util.ArrayList;

public class DisplayIngredientsActivity extends AppCompatActivity {
    ArrayList<Ingredient> ingredientArrayList;
    TextView textView;
    String measure, ingredient, quantity;
    StringBuilder stringBuilder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_ingredients);
        ingredientArrayList = new ArrayList<>();
        ingredientArrayList = getIntent().getParcelableArrayListExtra("ingredients");

        stringBuilder = new StringBuilder();

        textView = findViewById(R.id.tview);
        for (int i = 0; i < ingredientArrayList.size(); i++) {
            measure = ingredientArrayList.get(i).getMeasure();
            ingredient = ingredientArrayList.get(i).getIngredient();
            quantity = ingredientArrayList.get(i).getQuantity();

            stringBuilder.append("Ingredient :" + ingredient + "\n" + "Measure :" + quantity + "\t" + measure + "\n" + "\n");
        }

        textView.setText(stringBuilder);

    }

}
